#ifndef LAB05_AUXILIAR_H
#define LAB05_AUXILIAR_H

typedef char String[20];

/*
 * Função que verifica se uma String começa com uma determinada substring
 */
int comecaCom(String palavra, String prefixo);

#endif //LAB05_AUXILIAR_H
